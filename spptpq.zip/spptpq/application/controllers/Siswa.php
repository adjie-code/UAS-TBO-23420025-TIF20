<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}

	public function index()
	{
		$data = [
			'title'   => 'Dashboard',
			'url'     => 'dashboard',
			'content' => 'view_siswa',
			'header' => 'Siswa View'
		];

		$this->load->view('layout/index', $data, FALSE);		
	}

	public function insertData()
	{
		$data = [
					'nama_siswa' => $this->input->post('nama_siswa'),
					'jk' => $this->input->post('jk'),
					'alamat' => $this->input->post('alamat'),
					'nomor_induk' => $this->input->post('nomor_induk')
		];

		$insert = $this->query->insert('siswa', $data);
		if($insert) {
			$response['ping'] = 200;
		} else {
			$response['ping'] = 500;
		}

		echo json_encode($response);
	}
	
	public function loadTable()
	{
		$select = '*';
		$table  = 'siswa';
		$like['data'][] = [
			'column' => 'id_siswa, nama_siswa, jk, alamat, nomor_induk',
			'param'  => $this->input->get('search[value]')
		];

		

		$queryData  = $this->query->getData($select, $table, NULL, NULL);

		$result['data'] = [];
		if($queryData <> FALSE) {
			$no = 1;

			foreach($queryData->result() as $query) {
				if($query->id_siswa > 0) {
					if($query->jk=='p'){
						$ketgender = "Perempuan";
					}else{
						$ketgender = "Laki-laki";
					}
					$result['data'][] = [
						$no=$no,
						$query->nama_siswa,
						$ketgender,
						$query->alamat,
						$query->nomor_induk,
						'
						<button onclick="showData('.$query->id_siswa.')" class="btn btn-warning btn-circle btn-sm"><i class="fas fa-edit"></i></button>
						<button onclick="deleted('.$query->id_siswa.')" class="btn btn-danger btn-circle btn-sm" title="Delete Data"><i class="fa fa-trash"></i></button>
						'
					];
					$no++;
				}
			}
		}

		echo json_encode($result);
	}
	public function showData($id){
		$where = ['id_siswa' => $id];
		$data  = $this->query->getData('*', 'siswa', $where)->row();
		echo json_encode($data);
	}
	public function updateData($id)
	{
		$data = [
			'nama_siswa' => $this->input->post('nama_siswa'),
			'jk' => $this->input->post('jk'),
			'alamat' => $this->input->post('alamat'),
			'nomor_induk' => $this->input->post('nomor_induk')
		];

		$table  = ['column' => 'id_siswa', 'param' => $id, 'table' => 'siswa'];
		$update = $this->query->update($table, $data);
		if($update) {
			$response['ping'] = 200;
		} else {
			$response['ping'] = 500;
		}

		echo json_encode($response);
	}

	public function deleted($id){
		$where= [
			'id_siswa' => $id
		];
		$deleteData = $this->query->delete('siswa', $where);
		if($deleteData) {
			$response['ping'] = 200;
		} else {
			$response['ping'] = 500;
		}

		echo json_encode($response);
	}

}

/* End of file DataTPQ.php */
/* Location: ./application/controllers/DataTPQ.php */